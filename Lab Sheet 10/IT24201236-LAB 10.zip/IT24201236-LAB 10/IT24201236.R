setwd("C:\\Users\\My\\Desktop\\IT24201236-LAB 10")

observed <- c(120, 95, 85, 100)
chisq.test(observed)
